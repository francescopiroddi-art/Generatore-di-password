# Copyright (C) 2025 Francesco Piroddi
#
# Questo programma è software libero: puoi ridistribuirlo e/o modificarlo
# secondo i termini della Licenza Pubblica Generica GNU come pubblicata dalla
# Free Software Foundation, sia la versione 3 della Licenza, sia (a tua scelta)
# qualsiasi versione successiva.
#
# Questo programma è distribuito nella speranza che possa essere utile,
# ma SENZA ALCUNA GARANZIA; senza neppure la garanzia implicita di
# COMMERCIABILITÀ o IDONEITÀ PER UN PARTICOLARE SCOPO. Vedi la
# Licenza Pubblica Generica GNU per maggiori dettagli.
#
# Dovresti aver ricevuto una copia della Licenza Pubblica Generica GNU
# insieme a questo programma. In caso contrario, vedi <https://www.gnu.org/licenses/>.

import random
import string

def genera_password(lunghezza=12):
    """Genera una password sicura contenente almeno una lettera maiuscola, una minuscola, un numero e un simbolo."""
    if lunghezza < 4:
        raise ValueError("La lunghezza della password deve essere almeno 4 per includere tutti i tipi di caratteri.")

    # Assicuriamoci che la password contenga almeno un carattere di ogni tipo
    maiuscola = random.choice(string.ascii_uppercase)
    minuscola = random.choice(string.ascii_lowercase)
    numero = random.choice(string.digits)
    simbolo = random.choice(string.punctuation)

    # Riempimento del resto della password con caratteri casuali
    caratteri_rimanenti = lunghezza - 4
    tutti_caratteri = string.ascii_letters + string.digits + string.punctuation
    altri_caratteri = ''.join(random.choice(tutti_caratteri) for _ in range(caratteri_rimanenti))

    # Uniamo e mescoliamo i caratteri per evitare schemi prevedibili
    password = list(maiuscola + minuscola + numero + simbolo + altri_caratteri)
    random.shuffle(password)

    return ''.join(password)

# Esempio di utilizzo
if __name__ == "__main__":
    try:
        lunghezza_password = int(input("Inserisci la lunghezza della password (minimo 4): "))
        password_generata = genera_password(lunghezza_password)
        print(f"Password generata: {password_generata}")
    except ValueError as e:
        print(f"Errore: {e}")
